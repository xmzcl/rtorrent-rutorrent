﻿/*
 * PLUGIN CHECK_PORT
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.checkPort		= "Проверить статус порта";
 theUILang.portStatus		= [
 				  "Статус порта неизвестен",
 				  "Порт закрыт",
 				  "Порт открыт"
 				  ];

thePlugins.get("check_port").langLoaded();