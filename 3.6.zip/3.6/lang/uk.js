﻿/*
 * PLUGIN CHECK_PORT
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (pfactum@gmail.com)
 */

 theUILang.checkPort		= "Перевірити стан порту";
 theUILang.portStatus		= [
 				  "Стан порту невідомий",
 				  "Порт закрито",
 				  "Порт відкрито"
 				  ];

thePlugins.get("check_port").langLoaded();